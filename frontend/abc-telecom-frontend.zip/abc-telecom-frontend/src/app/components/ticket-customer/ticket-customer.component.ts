import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ticket-customer',
  templateUrl: './ticket-customer.component.html',
  styleUrls: ['./ticket-customer.component.css']
})
export class TicketCustomerComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
    
  }

}
