export class User {
    id:number;
    fullName:string;
    role:string;
    email:string;
    phone:string;
    password:string;
}


